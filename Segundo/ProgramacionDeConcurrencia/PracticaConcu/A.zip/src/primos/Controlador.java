package primos;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controlador implements ActionListener {
	private Panel panel = new Panel();
	private WorkerTwin workerTwin;
	private WorkerCousin workerCousin;
	private WorkerSexy workerSexy;
	
	
	
	public Controlador(Panel panel) {
		this.panel = panel;
	}

	
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getActionCommand().equals("Cancelar")) {
			if (workerTwin != null && !workerTwin.isDone()) {
		          workerTwin.cancel(true);
		        }
		    if (workerCousin != null && !workerCousin.isDone()) {
		          workerCousin.cancel(true);
		        }
		    if (workerSexy != null && !workerSexy.isDone()) {
		          workerSexy.cancel(true);
		        }
			panel.limpiaAreaCousin();
			panel.mensajeCousin("Area  primos 'cousin' creada");
			
			panel.limpiaAreaSexy();
			panel.mensajeSexy("Area  primos 'sexy' creada");
			
			panel.limpiaAreaTwin();
			panel.mensajeTwin("Area  primos 'twin' creada");
			
		      
			
		}else if(e.getActionCommand().equals("Numero1")) {
			workerTwin = new WorkerTwin(panel.numero1(), panel);
			workerTwin.execute();
			panel.mensajeTwin("Calculando primos twin...");
			
		}else if(e.getActionCommand().equals("Numero2")) {
			workerCousin = new WorkerCousin(panel.numero2(), panel);
			workerCousin.execute();
			panel.mensajeCousin("Calculando primos cousin...");
			
		}else if(e.getActionCommand().equals("Numero3")) {
			workerSexy = new WorkerSexy(panel.numero2(), panel);
			workerSexy.execute();
			panel.mensajeSexy("Calculando primos sexy...");
			
		}
		
	}
	

}
