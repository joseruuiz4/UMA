/**
 * 
 */
/**
 * 
 */
module PracticaConcu {
	requires java.desktop;
}