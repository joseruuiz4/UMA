package org.mps;

public class EvolutionaryAlgorithmException  extends Exception{
	public EvolutionaryAlgorithmException() {
		super();
	}
	public EvolutionaryAlgorithmException(String mensaje) {
		super(mensaje);
	}
}
